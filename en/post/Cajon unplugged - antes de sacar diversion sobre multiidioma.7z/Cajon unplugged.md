+++
categories = []
date = "2015-08-16T16:13:18-03:00"
description = ""
keywords = []
title = "Cajón unplugged"
slug = "cajon-unplugged"
type = "post"
lang = "en"

+++

I have just arrived from the hospital and I can confirm that Néstor's mood is *quite fine*.

He **unplugged** himself from the monitoring system, he grabbed a wood box very similar to a **"cajón"** (<a href="https://en.wikipedia.org/wiki/Caj%C3%B3n" target="_blank">Wikipedia article</a>) and started playing sitting on it.

The nurse, who had been focusing on another patient, soon realized and came to stop the show. Alas, I can *not* publish any pictures, she told us that it is forbidden to shoot any in there, and I don't want to risk causing her any trouble. According to her, Néstor's very positive mood will be of great help. The intervention is confirmed for Tuesday.

I forgot to ask what the wood box was for.

<hr>

Admittedly I should publish these articles in Spanish, as a priority (or Castellano to be more precise), although we *do* have friends abroad (mostly people who kept in touch after travelling to Buenos Aires and picking up our show in the list of acts... from Brasil, South Africa, Denmark, the USA...).

My previous website was multilingual and I plan to do the same on this one, at least for the most "static" content... As for the blog... I'll figure out... separate pages separate comments, or translated content sharing the same comments...

Many high traffic websites receive comments in any languages on the same page, they do not separate by language... and as I'm constantly very busy I don't plan to make of this website a high traffic forum, although giving the chance to leave comments seems a *very* nice feature to me. Honestly, I'm very tempted to leave the blog section *not* multilingual. Suggestions are welcome at this stage anyway.
